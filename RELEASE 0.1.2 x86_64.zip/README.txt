!Controls!
Written by Ethan Hughes

All games

Space - Pause
Tab - Change Game Speed

Snake

Arrow keys - change direction

Pathfinding

Left mouse - draw walls
Right mouse - erase walls
Enter - Attempt pathfinding

Mazes

Arrow keys - traverse maze

Pong

W and S - P1 paddle movement
Up and down keys - P2 paddle movement

Tetris

Left and right keys - Move piece

Conway's Game

Left mouse - draw life
Right mouse - erase life
Enter - start simulation

Space Invaders

Left and right keys - Move ship
Up key - Fire blaster

Frogger

Arrow keys - Move frog

Langston's Ant

Left mouse - draw white square
Right mouse - erase white square
Enter - start simulation

Connect 4

Left and right keys - Move piece to be placed
Down key - Place piece and switch turns

Flappy Bird

Up key - Wing hop

Checkers

Left mouse click - Select piece to move/Place piece in valid space/End turn after jumping/Stop selecting piece